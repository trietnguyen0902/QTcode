﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZXing;
using ZXing.Common;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        double ticketPrice = 2.50;
        double totalPrice = 0.0;
        public Form1()
        {
            InitializeComponent();
            comboBox1.Items.Clear();
            comboBox1.Items.Add("Bus Station A");
            comboBox1.Items.Add("Bus Station B");
            comboBox1.Items.Add("MRT Station C");
            comboBox1.Items.Add("MRT Station D");
            comboBox1.Visible = true;
            comboBox2.Items.Clear();
            comboBox2.Items.Add("Credit card");
            comboBox2.Items.Add("QR code");
            lblDestination.Visible = true;
            Selectdestination.Visible = true;
            lblmethod.Visible = true;
            Selectmethod.Visible = true;
            textReport.Visible = false;
            textDestination.Visible = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }


        private void Selectdestination_Click(object sender, EventArgs e)
        {
            string destination = comboBox1.Text;


            // Calculate total price based on destination and payment method
            if (destination.Contains("Bus"))
            {
                ticketPrice = 1.50;
               
            }
            else if (destination.Contains("MRT"))
            {
                ticketPrice = 2.50;
            }
            textDestination.Text = "Ticket to " + destination + " " + "\n";
            textDestination.Text += "Price per ticket: $\n" + ticketPrice + " " + "\n";
            textDestination.Visible = true;
        }

        private void Selectmethod_Click(object sender, EventArgs e)
        {
            string paymentMethod = comboBox2.Text;
            if (paymentMethod == "Credit card")
            {
                totalPrice = ticketPrice * 1.05; // Add 5% convenience fee for credit card
                // Generate barcode
                var writer = new BarcodeWriter();
                writer.Format = BarcodeFormat.CODE_128;
                var barcode = writer.Write(ticketPrice.ToString());
                picBarcode.Image = barcode;
            }
            else if (paymentMethod == "QR code")
            {
                string textToEncode = ticketPrice.ToString();

                // Set up the QR code writer
                BarcodeWriter writer = new BarcodeWriter
                {
                    Format = BarcodeFormat.QR_CODE,
                    Options = new EncodingOptions
                    {
                        Width = picQRCode.Width,
                        Height = picQRCode.Height
                    }
                };

                // Generate the QR code image and display it in the PictureBox
                Bitmap qrCodeImage = writer.Write(textToEncode);
                picQRCode.Image = qrCodeImage;
                }

        }

        private void Accept_Click(object sender, EventArgs e)
        {
            string destination = comboBox1.Text;
            string paymentMethod = comboBox2.Text;
            textReport.Text = "Ticket Vendor Machine to " + destination + " "+ "\n";
            textReport.Text += "Price per ticket: $\n" + ticketPrice + " " + "\n";
            textReport.Text += "Total price: $" + ticketPrice + " " + "\n";
            textReport.Text += "Payment method: " + paymentMethod + " " + "\n\n";
            textReport.Text += "Thank you for your purchase!";
            textReport.Visible = true;

            // Hide destination selection menu
            comboBox1.Visible = false;
            lblDestination.Visible = false;
            Selectdestination.Visible = false;
            comboBox2.Visible = false;
            lblmethod.Visible = false;
            Selectmethod.Visible = false;
            textDestination.Visible = false;
            picBarcode.Visible = false;
            picQRCode.Visible = false;
        }
    }   

    }

