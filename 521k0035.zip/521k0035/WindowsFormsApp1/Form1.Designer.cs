﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.Selectdestination = new System.Windows.Forms.Button();
            this.Selectmethod = new System.Windows.Forms.Button();
            this.lblDestination = new System.Windows.Forms.Label();
            this.picBarcode = new System.Windows.Forms.PictureBox();
            this.picQRCode = new System.Windows.Forms.PictureBox();
            this.textReport = new System.Windows.Forms.TextBox();
            this.lblmethod = new System.Windows.Forms.Label();
            this.Accept = new System.Windows.Forms.Button();
            this.textDestination = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.picBarcode)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picQRCode)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(127, 37);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 0;
            this.comboBox1.Text = "Destination";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(128, 137);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 1;
            this.comboBox2.Text = "Payment Method";
            // 
            // Selectdestination
            // 
            this.Selectdestination.Location = new System.Drawing.Point(127, 73);
            this.Selectdestination.Name = "Selectdestination";
            this.Selectdestination.Size = new System.Drawing.Size(104, 37);
            this.Selectdestination.TabIndex = 2;
            this.Selectdestination.Text = "select Destination";
            this.Selectdestination.UseVisualStyleBackColor = true;
            this.Selectdestination.Click += new System.EventHandler(this.Selectdestination_Click);
            // 
            // Selectmethod
            // 
            this.Selectmethod.Location = new System.Drawing.Point(128, 181);
            this.Selectmethod.Name = "Selectmethod";
            this.Selectmethod.Size = new System.Drawing.Size(104, 41);
            this.Selectmethod.TabIndex = 3;
            this.Selectmethod.Text = "select Payment method";
            this.Selectmethod.UseVisualStyleBackColor = true;
            this.Selectmethod.Click += new System.EventHandler(this.Selectmethod_Click);
            // 
            // lblDestination
            // 
            this.lblDestination.AutoSize = true;
            this.lblDestination.Location = new System.Drawing.Point(35, 37);
            this.lblDestination.Name = "lblDestination";
            this.lblDestination.Size = new System.Drawing.Size(60, 13);
            this.lblDestination.TabIndex = 5;
            this.lblDestination.Text = "Destination";
            // 
            // picBarcode
            // 
            this.picBarcode.Location = new System.Drawing.Point(557, 55);
            this.picBarcode.Name = "picBarcode";
            this.picBarcode.Size = new System.Drawing.Size(146, 142);
            this.picBarcode.TabIndex = 7;
            this.picBarcode.TabStop = false;
            // 
            // picQRCode
            // 
            this.picQRCode.Location = new System.Drawing.Point(557, 241);
            this.picQRCode.Name = "picQRCode";
            this.picQRCode.Size = new System.Drawing.Size(146, 146);
            this.picQRCode.TabIndex = 8;
            this.picQRCode.TabStop = false;
            // 
            // textReport
            // 
            this.textReport.Location = new System.Drawing.Point(89, 181);
            this.textReport.Margin = new System.Windows.Forms.Padding(10);
            this.textReport.MaximumSize = new System.Drawing.Size(800, 300);
            this.textReport.MinimumSize = new System.Drawing.Size(400, 100);
            this.textReport.Name = "textReport";
            this.textReport.Size = new System.Drawing.Size(676, 100);
            this.textReport.TabIndex = 9;
            // 
            // lblmethod
            // 
            this.lblmethod.AutoSize = true;
            this.lblmethod.Location = new System.Drawing.Point(35, 140);
            this.lblmethod.Name = "lblmethod";
            this.lblmethod.Size = new System.Drawing.Size(87, 13);
            this.lblmethod.TabIndex = 10;
            this.lblmethod.Text = "Payment Method";
            // 
            // Accept
            // 
            this.Accept.Location = new System.Drawing.Point(252, 326);
            this.Accept.Name = "Accept";
            this.Accept.Size = new System.Drawing.Size(79, 41);
            this.Accept.TabIndex = 11;
            this.Accept.Text = "Accept";
            this.Accept.UseVisualStyleBackColor = true;
            this.Accept.Click += new System.EventHandler(this.Accept_Click);
            // 
            // textDestination
            // 
            this.textDestination.Location = new System.Drawing.Point(293, 34);
            this.textDestination.MaximumSize = new System.Drawing.Size(500, 500);
            this.textDestination.MinimumSize = new System.Drawing.Size(100, 100);
            this.textDestination.Name = "textDestination";
            this.textDestination.Size = new System.Drawing.Size(231, 100);
            this.textDestination.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textDestination);
            this.Controls.Add(this.Accept);
            this.Controls.Add(this.lblmethod);
            this.Controls.Add(this.textReport);
            this.Controls.Add(this.picQRCode);
            this.Controls.Add(this.picBarcode);
            this.Controls.Add(this.lblDestination);
            this.Controls.Add(this.Selectmethod);
            this.Controls.Add(this.Selectdestination);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picBarcode)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picQRCode)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button Selectdestination;
        private System.Windows.Forms.Button Selectmethod;
        private System.Windows.Forms.Label lblDestination;
        private System.Windows.Forms.PictureBox picBarcode;
        private System.Windows.Forms.PictureBox picQRCode;
        private System.Windows.Forms.TextBox textReport;
        private System.Windows.Forms.Label lblmethod;
        private System.Windows.Forms.Button Accept;
        private System.Windows.Forms.TextBox textDestination;
    }
}

